
import numpy as np
import cv2
import matlplotlib.pyplot as plt
from sklearn.model_selection import train_test_split