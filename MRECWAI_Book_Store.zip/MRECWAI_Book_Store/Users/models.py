from django.db import models

# Create your models here.


class userRegisterModel(models.Model):
    user_id=models.CharField(max_length=25, unique=True)
    name=models.CharField(max_length=25)
    email=models.CharField(max_length=50)
    password=models.CharField(max_length=25)
    mobile=models.CharField(max_length=12)
    address=models.CharField(max_length=100)
    gender=models.CharField(max_length=10)

    def __str__(self):
        return self.userid
    
    class Meta:
        db_table = "userRegister"
    