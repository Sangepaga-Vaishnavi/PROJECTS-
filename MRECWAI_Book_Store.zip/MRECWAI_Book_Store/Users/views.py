from django.shortcuts import render

# Create your views here.
def SearchBooks():
    return "Hello Im SearchBooks"

def ViewBooks():
    return "Hello Im ViewBooks"

def AddToCart():
    return "Hello Im AddToCart"

def ViewCart():
    return "Hello Im ViewCart"

def CheckOut():
    return "Hello Im CheckOut"

def Payment():
    return "Hello Im Payment"

def ViewOrders():
    return "Hello Im ViewOrders"

def UserLogout():
    return "Hello Im ViewOrders"

