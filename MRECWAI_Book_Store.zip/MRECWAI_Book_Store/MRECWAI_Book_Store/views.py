from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request, 'base.html', {}) 
    
    
def Adminlogin(request):
    return render(request, 'AdminLogin.html', {}) 

def Userlogin(request):
    return render(request, 'UserLogin.html', {}) 
    

def UserRegister(request):
    return render(request, 'UserRegister.html', {}) 
    


