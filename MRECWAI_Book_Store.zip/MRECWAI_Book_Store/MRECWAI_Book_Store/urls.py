"""
URL configuration for MRECWAI_Book_Store project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.contrib import admin
from django.urls import path
from MRECWAI_Book_Store import views as mainview
from Admins import views as adminview 
from Users import views as userviews

urlpatterns = [
    path("admin/", admin.site.urls),
    #main loadind url patterns
    path("", mainview.index,name='index'),
    path("index", mainview.index,name='index'),
    path("AdminLogin/", mainview.Adminlogin,name='AdminLogin'),
    path("UserLogin/", mainview.Userlogin,name='UserLogin'),
    path("UserRegister/", mainview.UserRegister,name='UserRegister'),
    
    #Admin loading url patterns
    path("ViewAllUsers/", adminview.ViewAllUsers,name='ViewAllUsers'),
    path("NewRequests/", adminview.NewRequests,name='NewRequests'),
    path("AddBooks/", adminview.AddBooks,name='AddBooks'),
    path("ModifyBooks/", adminview.ModifyBooks,name='ModifyBooks'),
    path("ViewOrders/", adminview.ViewOrders,name='ViewOrders'),
    path("AdminLogout/", adminview.AdminLogout,name='AdminLogout'),
    
    #User loading url patterns
    path("SearchBooks/", userviews.SearchBooks,name='SearchBooks'),
    path("ViewBooks/", userviews.ViewBooks,name='ViewBooks'),
    path("AddToCart/", userviews.AddToCart,name='AddToCart'),
    path("ViewCart/", userviews.ViewCart,name='ViewCart'),
    path("CheckOut/", userviews.CheckOut,name='CheckOut'),
    path("Payment/", userviews.Payment,name='Payment'),
    path("ViewOrders/", userviews.ViewOrders,name='ViewOrders'),
    path("UserLogout/", userviews.UserLogout,name='UserLogout'),
    

    
]
