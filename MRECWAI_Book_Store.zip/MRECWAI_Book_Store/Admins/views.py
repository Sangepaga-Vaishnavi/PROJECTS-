from django.shortcuts import render

# Create your views here.
def ViewAllUsers():
    return "Hello Im Admin Root"

def NewRequests():
    return "Hello Im Admin Root"

def AddBooks():
    return "Hello Im Admin Root"

def ModifyBooks():
    return "Hello Im Admin Root"

def ViewOrders():
    return "Hello Im Admin Root"

def AdminLogout():
    return "Hello Im Admin Root"